---
name: Bug Report - DO NOT DELETE PREWRITTEN TEXT
about: Make sure you have looked through the Closed Topics & the Wiki before submitting
  an issue as you accept any Punishments.
title: ''
labels: Bug
assignees: ''

---

**Describe the Bug | A Clear & Concise Description of Bug**


**Questions**
Have you made changes to anything in `client/main.lua` or `server/main.lua`?: 
Have you looked through the Closed Topics?: 
Have you looked through the Wiki?: 
Are you using a Pre-Installed ESX? If Yes who?: 
Are you using es_extended? If Yes what Version? (Example: 1.2): 
Are you using Essentialmode?: 
Are you using ExtendedMode?: 
Are you using OneSync?: 
Linux or Windows?: 
